package com.example.PluralizadorAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PluralizadorApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PluralizadorApiApplication.class, args);
	}

}
