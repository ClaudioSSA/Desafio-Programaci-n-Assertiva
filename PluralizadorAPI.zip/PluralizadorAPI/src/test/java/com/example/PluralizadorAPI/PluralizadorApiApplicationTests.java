package com.example.PluralizadorAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PluralizadorApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
